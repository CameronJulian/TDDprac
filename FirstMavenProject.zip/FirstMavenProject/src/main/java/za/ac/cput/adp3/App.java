package za.ac.cput.adp3;

/**
 * Nico Fortuin
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Welcome to my first maven project." );
    }
}
